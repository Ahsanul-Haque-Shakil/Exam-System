<?php
    // Include the header file
    include('header.php');
?>

<h1>About Us</h1>

<div class="box">
    <img src="person1.jpg" alt="Person 1" width="100" height="100">
    <div class="name">Person 1</div>
    <div class="details">
        <p>Role: Developer</p>
        <p>Email: person1@example.com</p>
    </div>
</div>

<div class="box">
    <img src="image/bg1.jpg" alt="Person 2" width="100" height="100">
    <div class="name">Person 2</div>
    <div class="details">
        <p>Role: Designer</p>
        <p>Email: person2@example.com</p>
    </div>
</div>

<div class="box">
    <img src="person3.jpg" alt="Person 3" width="100" height="100">
    <div class="name">Person 3</div>
    <div class="details">
        <p>Role: Project Manager</p>
        <p>Email: person3@example.com</p>
    </div>
</div>

<div class="box">
    <img src="person4.jpg" alt="Person 4" width="100" height="100">
    <div class="name">Person 4</div>
    <div class="details">
        <p>Role: Tester</p>
        <p>Email: person4@example.com</p>
    </div>
</div>

<?php
    // Include the necessary CSS and JavaScript files
    echo '<link rel="stylesheet" href="css/bootstrap.min.css" />';
    echo '<link rel="stylesheet" href="css/bootstrap-theme.min.css" />';
    echo '<link rel="stylesheet" href="css/main.css" />';
    echo '<link rel="stylesheet" href="css/font.css" />';
    echo '<script src="js/jquery.js" type="text/javascript"></script>';
    echo '<script src="js/bootstrap.min.js"  type="text/javascript"></script>';

    // Include the footer file
    include('footer.php');
?>
